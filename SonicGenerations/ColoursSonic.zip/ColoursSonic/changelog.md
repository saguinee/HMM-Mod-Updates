## Colours Sonic Version 1.2.1
- Blue Simulator's eye and body textures now appear on the title screen
- don't get on my case about your UK spelling bruh i live in america leave me be
## Colours Sonic Version 1.2
- Now appears on the title screen and in cutscenes
## Colours Sonic Version 1.1
- Fixed jumpball speed rotating too fast
## Colours Sonic Version 1.0.1
- Fixed config defaulting to Red Sim Sonic
## Colours Sonic Version 1.0
- First release
